import os
from utils.helpers import load_data, find_answer

class MilliFruitModel:
    def __init__(self):
        data_folder = os.path.join(os.path.dirname(__file__), "../data")
        self.data_en = load_data(os.path.join(data_folder, "data-en.txt"))
        self.data_fr = load_data(os.path.join(data_folder, "data-fr.txt"))

    def ask(self, question, lang="en"):
        if lang == "fr":
            return find_answer(question, self.data_fr)
        else:
            return find_answer(question, self.data_en)
