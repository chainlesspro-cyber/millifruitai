import re

def load_data(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read().split("\n\n")  # chaque paragraphe séparé par double saut de ligne

def find_answer(question, data):
    question_words = re.findall(r'\w+', question.lower())  # mots dans la question
    best_paragraph = ""
    best_score = 0

    for paragraph in data:
        paragraph_words = re.findall(r'\w+', paragraph.lower())
        # score = nombre de mots de la question présents dans le paragraphe
        score = sum(1 for word in question_words if word in paragraph_words)
        if score > best_score:
            best_score = score
            best_paragraph = paragraph

    if best_score == 0:
        return "I don't know the answer yet."
    return best_paragraph
