from flask import Flask, request, jsonify, render_template
from model.model import MilliFruitModel  # importe la classe

app = Flask(__name__, template_folder="../templates")

# crée l'instance de l'IA
model = MilliFruitModel()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    question = data.get("question")
    lang = data.get("lang", "en")
    answer = model.ask(question, lang)
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
